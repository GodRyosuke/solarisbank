$(function(){
	$("button").html("Click");
});