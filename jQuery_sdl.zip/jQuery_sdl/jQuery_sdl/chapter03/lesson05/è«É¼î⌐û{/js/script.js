$(function(){
  // アイコンをクリック
  $("button").click(function(){
    // ul要素を開閉
    $("ul").slideToggle(200);
  });
});
