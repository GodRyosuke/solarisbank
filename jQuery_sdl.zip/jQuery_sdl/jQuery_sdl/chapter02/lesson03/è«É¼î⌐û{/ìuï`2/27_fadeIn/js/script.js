$(function(){
	$("p").fadeIn();

	// 速度指定
	// $("p").fadeIn(1000);

	// 終了後の処理を指定
	// $("p").fadeIn(function(){
	// 	$(this).css("color", "#FF0000");
	// });
});
