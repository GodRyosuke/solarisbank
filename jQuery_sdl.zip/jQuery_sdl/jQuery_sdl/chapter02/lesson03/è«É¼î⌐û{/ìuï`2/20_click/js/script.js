$(function(){
  $("a").click(function(){
    $(this).css("color", "#FF0000");
    return false;
  });
});
