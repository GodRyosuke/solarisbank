$(function(){
  $("p").removeClass("textRed");
});
