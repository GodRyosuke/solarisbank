$(function(){
  $("p").css("color", "#FF0000");
});
