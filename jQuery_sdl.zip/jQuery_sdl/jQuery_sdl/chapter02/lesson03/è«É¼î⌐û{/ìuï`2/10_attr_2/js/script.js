$(function(){
  $("p").html($("img").attr("src"));
});
