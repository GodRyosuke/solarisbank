$(function(){
  $("p").html("<strong>HELLO WORLD!</strong>");
});
