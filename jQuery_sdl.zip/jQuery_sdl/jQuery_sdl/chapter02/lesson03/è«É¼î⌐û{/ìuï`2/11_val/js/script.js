$(function(){
  $("p").html($("input").val());
});
