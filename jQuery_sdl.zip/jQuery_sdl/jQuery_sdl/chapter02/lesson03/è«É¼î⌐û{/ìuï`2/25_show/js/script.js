$(function(){
  $("p").show();
});
