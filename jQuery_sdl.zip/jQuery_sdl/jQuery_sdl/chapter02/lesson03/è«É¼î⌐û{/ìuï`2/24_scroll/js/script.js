$(function(){
  $(window).scroll(function(){
    $("p").css("color", "#FF0000");
  });
});
