$(function(){
  $("p").html("Height:" + $("div").height() + "px");
});
