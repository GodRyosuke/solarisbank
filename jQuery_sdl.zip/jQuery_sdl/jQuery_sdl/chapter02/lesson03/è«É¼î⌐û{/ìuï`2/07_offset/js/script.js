$(function(){
  $("p").html("Top:" + $("p").offset().top + "px Left:" + $("p").offset().left + "px");
});
