$(function(){
  $("p").fadeOut();

  // 速度指定
	// $("p").fadeOut(1000);

	// 終了後の処理を指定
  // $("p").fadeOut(function(){
  //   alert("フェードアウトしました");
  // });
});
