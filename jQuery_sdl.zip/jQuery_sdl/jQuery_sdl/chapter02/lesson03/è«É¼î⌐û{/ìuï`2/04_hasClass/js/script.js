$(function(){
  if($("p").hasClass("textRed")){
    $("p").html("Yes");
  }else{
    $("p").html("No");
  }
});
