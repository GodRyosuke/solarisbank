$(function(){
  $("div").children().css("color", "#FF0000");
});
