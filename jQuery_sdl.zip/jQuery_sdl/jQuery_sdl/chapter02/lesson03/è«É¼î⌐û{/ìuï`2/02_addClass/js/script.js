$(function(){
  $("p").addClass("textRed");
});
