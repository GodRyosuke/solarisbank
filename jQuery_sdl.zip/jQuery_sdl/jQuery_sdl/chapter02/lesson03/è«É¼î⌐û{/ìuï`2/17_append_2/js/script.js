$(function(){
  $("ul").append($("li:first-child"));
});
