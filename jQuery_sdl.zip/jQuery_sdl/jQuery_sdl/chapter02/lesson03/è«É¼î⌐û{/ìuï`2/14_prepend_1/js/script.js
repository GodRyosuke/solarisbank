$(function(){
  $("ul").prepend("<li>List1</li>");
});
