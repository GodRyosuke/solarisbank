$(function(){
  $("a").hover(function(){
    $(this).css("color", "#FF0000");
  });
});
