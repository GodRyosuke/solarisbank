$(function(){
  $("p").html($("span").html());
});
