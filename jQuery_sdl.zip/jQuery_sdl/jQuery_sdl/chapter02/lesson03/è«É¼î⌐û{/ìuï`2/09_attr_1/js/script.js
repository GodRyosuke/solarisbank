$(function(){
  $("img").attr("src", "img2.png");
});
