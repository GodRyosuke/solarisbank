$(function(){
  $("p").hide();
});
