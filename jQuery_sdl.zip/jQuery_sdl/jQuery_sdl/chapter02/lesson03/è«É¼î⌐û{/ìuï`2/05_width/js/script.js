$(function(){
  $("p").html("Width:" + $("div").width() + "px");
});
