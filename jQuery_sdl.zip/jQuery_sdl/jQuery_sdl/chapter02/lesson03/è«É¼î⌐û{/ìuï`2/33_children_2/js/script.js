$(function(){
  $("div").children("span").css("color", "#FF0000");
});
