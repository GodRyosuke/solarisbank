$(function(){
  $("ul").prepend($("li:last-child"));
});
