$(function(){
  $("ul").append("<li>List3</li>");
});
