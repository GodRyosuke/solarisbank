$(function(){
  $("p").html("Index:" + $("#target").index());
});
