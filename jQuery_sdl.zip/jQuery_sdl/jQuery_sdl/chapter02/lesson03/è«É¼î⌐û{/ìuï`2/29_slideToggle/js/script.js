$(function(){
  $("dt").click(function(){
    $("dd").slideToggle();
  });
});
