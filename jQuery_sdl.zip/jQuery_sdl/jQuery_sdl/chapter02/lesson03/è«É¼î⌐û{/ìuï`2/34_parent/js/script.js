$(function(){
  $("p").parent().css("border", "1px solid #FF0000");
});
