$(function(){
  $("#target").remove();
});
