$(function(){



	$("button").click(function(){
		// $(this)
		$(this).html("Click").css("background", "#000033");
	});
});
